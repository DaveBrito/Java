
package calculomedia;
import java.util.Scanner;
public class CalculoMedia {

    public static void main(String[] args) {
      Aluno Aluno = new Aluno();
      Aluno.lerDados();
      Aluno.CalcularMedia();
    }
    
}
