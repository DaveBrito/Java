/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backendzsdmnoite20221.model.dao;

import backendzsdmnoite20221.model.bean.UsuarioPessoa;
import backendzsdmnoite20221.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProfAlexandre
 */
public class DaoUsuarioPessoa {
    
    private final Connection c;
    
    public DaoUsuarioPessoa() throws SQLException, ClassNotFoundException{
        this.c = new Conexao().getConnection();
    }

    public UsuarioPessoa excluir(UsuarioPessoa usuPessEntrada) throws SQLException {
        String sql = "delete from usuarios_pessoas WHERE id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,usuPessEntrada.getId());
        // executa
        stmt.execute();
        stmt.close();
        c.close();
        return usuPessEntrada;
    }

    public UsuarioPessoa alterar(UsuarioPessoa usuPessEntrada) throws SQLException {
        String sql = "UPDATE usuarios_pessoas SET idUsu = ?, idPes = ?, observacao = ? WHERE id = ?";
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql);
        // seta os valores
        stmt.setInt(1,usuPessEntrada.getIdU());
        stmt.setInt(2,usuPessEntrada.getIdP());
        stmt.setString(3,usuPessEntrada.getObs());
        stmt.setInt(4,usuPessEntrada.getId());

        // executa
        stmt.execute();
        stmt.close();
        return usuPessEntrada;

    }

    public List<UsuarioPessoa> listar(UsuarioPessoa usuPessEntrada) throws SQLException {
            // usus: array armazena a lista de registros

        List<UsuarioPessoa> listapl = new ArrayList<>();
        
        String sql = "select * from usuarios_pessoas where observacao like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + usuPessEntrada.getObs() + "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            UsuarioPessoa pl = new UsuarioPessoa(
                rs.getInt(1),
                rs.getInt(2),
                rs.getInt(3),
                rs.getString(4)
            );
            // adiciona o usu à lista de usus
            listapl.add(pl);
        }
        
        rs.close();
        stmt.close();
        
        return listapl;
    
    }

    public UsuarioPessoa buscar(UsuarioPessoa usuPessEntrada) throws SQLException {
        String sql = "select * from usuarios_pessoas WHERE id = ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,usuPessEntrada.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            UsuarioPessoa retorno = null;
            while (rs.next()) {      
            // criando o objeto Usuario
                retorno = new UsuarioPessoa(
                    rs.getInt(1),
                    rs.getInt(2),
                    rs.getInt(3),
                    rs.getString(4));
            // adiciona o usu à lista de usus
            }
            stmt.close();
            return retorno;

    }

    public UsuarioPessoa inserir(UsuarioPessoa usuPessEntrada) throws SQLException {
        String sql = "insert into usuarios_pessoas" + " (idUsu, idPes, observacao)" + " values (?,?,?)";
    
        // prepared statement para inserção
        PreparedStatement stmt = c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);

        // seta os valores
        stmt.setInt(1,usuPessEntrada.getIdU());
        stmt.setInt(2,usuPessEntrada.getIdP());
        stmt.setString(3,usuPessEntrada.getObs());
 
        // executa
        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            usuPessEntrada.setId(id);
        }
        stmt.close();
        return usuPessEntrada;



    }
    
}
