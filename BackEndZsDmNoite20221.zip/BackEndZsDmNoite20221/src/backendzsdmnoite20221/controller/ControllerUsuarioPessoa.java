/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backendzsdmnoite20221.controller;

import backendzsdmnoite20221.model.bean.PessoaFisica;
import backendzsdmnoite20221.model.bean.Usuario;
import backendzsdmnoite20221.model.bean.UsuarioPessoa;
import backendzsdmnoite20221.model.dao.DaoUsuarioPessoa;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ProfAlexandre
 */
public class ControllerUsuarioPessoa {
    
    DaoUsuarioPessoa daoPl = null;

    public UsuarioPessoa excluir(UsuarioPessoa usuPesEntrada) throws SQLException, ClassNotFoundException {
        daoPl = new DaoUsuarioPessoa();
        return daoPl.excluir(usuPesEntrada);
    }

    public UsuarioPessoa alterar(UsuarioPessoa usuPesEntrada) throws SQLException, ClassNotFoundException {
        daoPl = new DaoUsuarioPessoa();
        return daoPl.alterar(usuPesEntrada);
    }

    public List<UsuarioPessoa> listar(UsuarioPessoa usuPesEntrada) throws SQLException, ClassNotFoundException {
        daoPl = new DaoUsuarioPessoa();
        List<UsuarioPessoa> listausupes = daoPl.listar(usuPesEntrada);
        List<UsuarioPessoa> listausupesAux = new ArrayList<>();
        for (UsuarioPessoa usupes : listausupes) {
            listausupesAux.add(buscar(usupes));
        }
        return listausupesAux;
    }

    public UsuarioPessoa buscar(UsuarioPessoa usuPesEntrada) throws SQLException, ClassNotFoundException {
        daoPl = new DaoUsuarioPessoa();
        UsuarioPessoa usupes = daoPl.buscar(usuPesEntrada);

        ControllerPessoaFisica contP = new ControllerPessoaFisica();
        PessoaFisica pfEntrada = new PessoaFisica(usupes.getIdP());
        usupes.setPf(contP.buscar(pfEntrada));
        
        ControllerUsuario contUsu = new ControllerUsuario();
        Usuario usuEntrada = new Usuario(usupes.getIdU());
        usupes.setUsu(contUsu.buscar(usuEntrada));
        
        return usupes;
    }

    public UsuarioPessoa inserir(UsuarioPessoa usuPesEntrada) throws SQLException, ClassNotFoundException {
        daoPl = new DaoUsuarioPessoa();
        return daoPl.inserir(usuPesEntrada);
    }
    
}
