/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;


import config.conection;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import static jdk.nashorn.internal.runtime.Debug.id;


/**
 *
 * @author Junior
 */
public class Alterar extends javax.swing.JFrame {

    conection con1 = new conection();   
    Connection conet = null;
    Statement st;
    ResultSet rs = null;
    int idc;
       
    Connection con;
    String url = "jdbc:mysql://localhost:3306/cadastro"; 
    String usuario = "dav"; 
    String senha = ""; 

   
    public Alterar() {
        initComponents();
    }
    
void Buscar() throws SQLException{
try {
    Class.forName("com.mysql.jdbc.Driver");
    con = DriverManager.getConnection(url, usuario, senha);
    Object[] cliente = new Object[6];
    st = con.createStatement();
    rs = st.executeQuery("SELECT * FROM cliente");

    DefaultTableModel modelo = new DefaultTableModel();
    modelo.addColumn("ID");
    modelo.addColumn("Nome");
    modelo.addColumn("Telefone");
    modelo.addColumn("Email");
    modelo.addColumn("CEP");
    modelo.addColumn("Endereco"); 
    
    while (rs.next()) {
        
        cliente[0] = rs.getString("id");
        cliente[1] = rs.getString("Nome");
        cliente[2] = rs.getString("Telefone");
        cliente[3] = rs.getString("Email");
        cliente[4] = rs.getString("CEP");
        cliente[5] = rs.getString("Endereco");
        modelo.addRow(cliente);
    }
    tb.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseClicked(MouseEvent e) {
        int linhaSelecionada = tb.getSelectedRow();
        if (linhaSelecionada >= 0) {
            // Obter os dados da linha selecionada
            String id = tb.getValueAt(linhaSelecionada, 0).toString();
            String nome = tb.getValueAt(linhaSelecionada, 1).toString();
            String telefone = tb.getValueAt(linhaSelecionada, 2).toString();
            String email = tb.getValueAt(linhaSelecionada, 3).toString();
            String cep = tb.getValueAt(linhaSelecionada, 4).toString();
            String endereco = tb.getValueAt(linhaSelecionada, 5).toString();
            modeloId.setEditable(false);

            // Atualizar os campos de texto com os dados da linha selecionada
            modeloId.setText(id);
            modeloNome.setText(nome);
            modeloTelefone.setText(telefone);
            modeloEmail.setText(email);
            modeloCep.setText(cep);
            modeloEndereco.setText(endereco);
        }
    }
     
});
        tb.setModel(modelo);
} catch (ClassNotFoundException e) {
} 

    
}
 



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        modeloEndereco = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        modeloId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        modeloCep = new javax.swing.JTextField();
        modeloTelefone = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        modeloEmail = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        JTextField = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        modeloNome = new javax.swing.JTextField();
        Endereco = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("ALTERAR DADOS");

        tb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Telefone", "Email", "CEP", "Endereco"
            }
        ));
        tb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb);

        jLabel2.setText("ID");

        jLabel3.setText("Nome");

        jLabel4.setText("Telefone");

        jLabel5.setText("Email");

        jLabel6.setText("CEP");

        JTextField.setText("ALTERAR");
        JTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTextFieldActionPerformed(evt);
            }
        });

        jButton1.setText("MENU");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Endereco.setText("Endereco");

        jButton2.setText("EXCLUIR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("EXIBIR");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(42, 42, 42)
                                    .addComponent(jLabel2)
                                    .addGap(18, 18, 18)
                                    .addComponent(modeloId, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                    .addGap(19, 19, 19)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(18, 18, 18)
                                            .addComponent(modeloNome, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(6, 6, 6))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(modeloTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(JTextField)
                                .addGap(18, 18, 18)
                                .addComponent(jButton1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(33, 33, 33)
                                        .addComponent(Endereco)
                                        .addGap(18, 18, 18))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(28, 28, 28)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(modeloEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(modeloEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(modeloCep, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(jButton3)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modeloEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(modeloId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modeloNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(modeloEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Endereco))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modeloTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(modeloCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JTextField)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3)
                .addGap(5, 5, 5))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 380, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbMouseClicked
        
    }//GEN-LAST:event_tbMouseClicked

    private void JTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTextFieldActionPerformed
        try {
            atualizarDadosSelecionados();
        } catch (SQLException ex) {
            Logger.getLogger(Alterar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JTextFieldActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     Menu newframe = new Menu(); //Aba para retornar para o menu.
     newframe.setVisible(true); //Significa que a janela será exibida na tela. Isso permite que o usuário volte para a aba do menu..
     this.dispose(); //Significa que a janela atual será fechada, dando lugar à exibição da nova janela do menu.
 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            DeletarDados();         //Atribuindo função para deletar os dados.
        } catch (SQLException ex) {
            Logger.getLogger(Alterar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            Buscar();       //Exibir os dados da tabela na janela aberta.
        } catch (SQLException ex) {
            Logger.getLogger(Alterar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
         
        java.awt.EventQueue.invokeLater(new Runnable() {
            
            public void run() {
                new Alterar().setVisible(true);
            }
     
        
      });
        
    
        
    }
    
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Endereco;
    private javax.swing.JButton JTextField;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField modeloCep;
    private javax.swing.JTextField modeloEmail;
    private javax.swing.JTextField modeloEndereco;
    private javax.swing.JTextField modeloId;
    private javax.swing.JTextField modeloNome;
    private javax.swing.JTextField modeloTelefone;
    private javax.swing.JTable tb;
    // End of variables declaration//GEN-END:variables

    private void atualizarDadosSelecionados() throws SQLException {
        //Será atribuido novas variáveis para receber os dados já instânciados.
String novoValor1 = modeloNome.getText();   //Novos valores receberam os dados digitados no campo.
String novoValor2 = modeloTelefone.getText();
String novoValor3 = modeloId.getText();
String novoValor4 = modeloEmail.getText();
String novoValor5 = modeloCep.getText();
String novoValor6 = modeloEndereco.getText();

try (Connection con = DriverManager.getConnection(url, usuario, senha)) {   //Função de conexão com o banco para executar o insert.
  
    String sql = "SELECT nome, telefone, email, cep, endereco FROM cliente WHERE id = ?"; //Função sql com statement com parâmetro '?' . !=SELECT nome WHERE id = 2;.
    PreparedStatement selectStatement = con.prepareStatement(sql);  //Statement sendo obrigatório para funcionar os comandos sql.
    selectStatement.setString(1, novoValor3); // Use novoValor3 para obter o ID correto
    ResultSet resultSet = selectStatement.executeQuery();   //Armazena a consulta, resultSet.

    // 
    if (resultSet.next()) { //Irá rodar essa lista com os valores para serem pegos.
        String valorAntigo1 = resultSet.getString("nome");  //Recebe todos os dados digitados.
        String valorAntigo2 = resultSet.getString("telefone");
        String valorAntigo4 = resultSet.getString("email");
        String valorAntigo5 = resultSet.getString("cep");
        String valorAntigo6 = resultSet.getString("endereco");
        
            //sqlUp é o nome da variável para identificar como update.
            String sqlUp = "UPDATE cliente SET nome = ?, telefone = ?, email = ?, cep = ?, endereco = ? WHERE id = ?";
            PreparedStatement updateStatement = con.prepareStatement(sqlUp);    //Atualiza os dados.
            updateStatement.setString(1, novoValor1);  //Está recebendo o valor do Antigo1, sendo armazenado em outra variável.
            updateStatement.setString(2, novoValor2);   //Antigo2
            updateStatement.setString(3, novoValor4);   //Antigo3
            updateStatement.setString(4, novoValor5);   //Antigo4
            updateStatement.setString(5, novoValor6);   //Antigo5
            updateStatement.setString(6, novoValor3);   //Antigo6, id do cliente.

            int linhasAfetadas = updateStatement.executeUpdate();  //Executa a função de atualizar os dados'executeUpddate'..       
            JOptionPane.showMessageDialog(null,"Dados atualizados com sucesso.");           
        
    } //Caso não execute, rode essa mensagem no console.
} catch (SQLException e) {
    System.out.println("Erro ao executar a atualização no banco de dados. Erro: " + e);
}
} 

    private void DeletarDados() throws SQLException {
        
        int saida = JOptionPane.showConfirmDialog(null, "Deseja excluir esse cliente?");//Função de confirmação de exclusão.
        
        if(saida == JOptionPane.YES_OPTION) {     
            
       String sqlDelete = "DELETE FROM cliente WHERE id = ?";
       PreparedStatement deleteStatement = con.prepareStatement(sqlDelete);//Função para excluir os dados do cliente apenas buscando seu id..
       String novoValor3 = modeloId.getText();//Sendo pego os dados do cliente pelo seu registro 'id'.
       deleteStatement.setString(1, novoValor3); //Valor3 se destina ao ID do cliente 'modeloID'..
       
       int linhasAfetadas = deleteStatement.executeUpdate();//Função que recebe o comando sql para a ação..'executeUpdate'   
       System.out.println("Registro deletado com sucesso.");      
    }
        
        
        
   
        
        
        
        
        
        
        
        
        
        
    }
 } 



    

